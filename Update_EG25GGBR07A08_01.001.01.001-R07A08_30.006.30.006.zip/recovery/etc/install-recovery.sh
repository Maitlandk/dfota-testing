#!/system/bin/sh
if ! applypatch -c MTD:recovery:6211584:0cc367273e16d513c4bedbf3c9f777cb9aef0990; then
  log -t recovery "Installing new recovery image"
  applypatch MTD:boot:6211584:0cc367273e16d513c4bedbf3c9f777cb9aef0990 MTD:recovery 0cc367273e16d513c4bedbf3c9f777cb9aef0990 6211584 0cc367273e16d513c4bedbf3c9f777cb9aef0990:/system/recovery-from-boot.p
else
  log -t recovery "Recovery image already installed"
fi
