#!/system/bin/sh
if ! applypatch -c MTD:recovery:6158336:85c514d8c1af17520e9d770e31c4ed7e6b03f0cd; then
  log -t recovery "Installing new recovery image"
  applypatch MTD:boot:6158336:85c514d8c1af17520e9d770e31c4ed7e6b03f0cd MTD:recovery 85c514d8c1af17520e9d770e31c4ed7e6b03f0cd 6158336 85c514d8c1af17520e9d770e31c4ed7e6b03f0cd:/system/recovery-from-boot.p
else
  log -t recovery "Recovery image already installed"
fi
